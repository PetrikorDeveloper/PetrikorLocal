
<div class="dgwt_jg_promobox-lightbox dgwt_jg_promobox-photoswipe">
    <h4 class="dgwt-jg-promobox__title"><?php _e('See how the Swipebox works', 'justified-gallery'); ?></h4>

    <?php echo do_shortcode('[gallery lightbox="swipebox" hover="none" margin=3 lastRow=justify demo="1"]') ?>
</div>
