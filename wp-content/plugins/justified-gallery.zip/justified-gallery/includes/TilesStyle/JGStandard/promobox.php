
<div class="dgwt_jg_promobox-hover dgwt_jg_promobox-jgstandrad">
    <h4 class="dgwt-jg-promobox__title"><?php _e('See how the JG Standard style looks', 'justified-gallery'); ?></h4>

    <?php echo do_shortcode('[gallery link="none" hover="standard" margin=3 lastRow=justify demo="1"]') ?>
</div>