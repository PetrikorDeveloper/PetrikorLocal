
<div class="dgwt_jg_promobox-hover dgwt_jg_promobox-layla">
    <h4 class="dgwt-jg-promobox__title"><?php _e('See how the Layla style looks', 'justified-gallery'); ?></h4>

	<?php echo do_shortcode('[gallery link="none" hover="layla" margin=3 lastRow=justify demo="1"]') ?>
</div>
